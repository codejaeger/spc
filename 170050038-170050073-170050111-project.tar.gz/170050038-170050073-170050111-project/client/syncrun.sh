#!/bin/bash
echo $(date +%s) > lastsync.txt

