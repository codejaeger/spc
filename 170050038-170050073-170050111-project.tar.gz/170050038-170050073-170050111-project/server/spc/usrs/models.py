# django
from django.db import models
# third party
from pyDes import *
from django.contrib.auth.models import User
from db_file_storage.model_utils import delete_file, delete_file_if_needed, exists
from db_file_storage.compat import reverse
import hashlib
from django.core.exceptions import ValidationError 
from django.shortcuts import render, redirect
from db_file_storage.storage import Encryptor
#class
import blowfish

class BookIndex(models.Model):
    book_index_pk = models.AutoField(primary_key=True)
    bytes = models.TextField()
    filename = models.CharField(max_length=255)
    mimetype = models.CharField(max_length=50)

#class BookPages(models.Model):
#    book_pages_pk = models.AutoField(primary_key=True)
#    bytes = models.TextField()
   # filename = models.CharField(max_length=255)
#    mimetype = models.CharField(max_length=50)
##
##
#class BookCover(models.Model):
#    book_cover_pk = models.AutoField(primary_key=True)
#    bytes = models.BinaryField()
#    filename = models.CharField(max_length=255)
#    mimetype = models.CharField(max_length=50)


class Book(models.Model):
    book_pk = models.AutoField(primary_key=True)
    ownr = models.ForeignKey(User,related_name='files',on_delete=models.CASCADE)
#    ownw = models.ForeignKey(max_length=100)
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    md5s = models.CharField(max_length=100,null=True)
    md5so = models.CharField(max_length=100,null=True)
    md5se = models.CharField(max_length=100,null=True)
    index = models.FileField(
        upload_to='usrs.BookIndex/bytes/filename/mimetype',
        blank=False, null=True
    )
    sharedwith = models.ManyToManyField(User)
    key=None
    scm=None
    low=None
    class Meta:
        unique_together = ("name","ownr","md5s")
#    pages = models.FileField(
#        upload_to='model_filefields_example.BookPages/bytes/filename/mimetype',
#        blank=True, null=True
#    )
#    cover = models.ImageField(
#        upload_to='model_filefields_example.BookCover/bytes/filename/mimetype',
#        blank=True, null=True
#    )

    def get_absolute_url(self):
        return reverse('model_files:book.edit', kwargs={'pk': self.pk})

#     def save(self, *args, **kwargs):
#         # delete_file_if_needed(self, 'index')
# #        delete_file_if_needed(self, 'pages')
#         try:
#             super(Book, self).save(*args, **kwargs)
#         except IntegrityError:
#             if exists(self,'index'):
#                 return reverse('model_files:book.delete', kwargs={'pk': self.pk})
              
#     def save(self, *args, **kwargs):
#         if exists(self,'index'):
#             return reverse('model_files:book.delete', kwargs={'pk': self.pk})
#         # delete_file_if_needed(self, 'index')
# #        delete_file_if_needed(self, 'pages')
#         else:
#             super(Book, self).save(*args, **kwargs)
#     def save(self, *args, **kwargs):
#         # if exists(self,'index') and self.exists('index'):
#             # return reverse('model_files:book.overwrite')

#         # delete_file_if_needed(self, 'index')
#         if not self.pk:  # file is new
#             md5 = hashlib.md5()
#             for chunk in self.index.chunks():
#                 md5.update(chunk)
#             self.md5s = md5.hexdigest()
#         # encrypted_file =  subprocess.call(['gpg','--yes','--batch','--passphrase="a"','-c',self.index])
# #        delete_file_if_needed(self, 'pages')
#         # else:
#         # try:
#         #     super(Book, self).save(*args, **kwargs)
#         # except:
#         if Book.objects.filter(name=self.name,ownr=self.ownr):
#             sd=Book.objects.get(name=self.name,ownr=self.ownr)

#             if self.md5se:
#                 sd.delete()
#                 super(Book, self).save(*args, **kwargs)
#                 return True
#             else:
#                 if sd.md5s!=self.md5s:
#                     return False
#                 else:
#                     return True
#                         # raise ValidationError(self.md5s)
#                     # return redirect('model_files:book.edit', kwargs={'pk': sd.pk})
#         else:
#             if self.md5se:
#                 if self.md5s == self.md5se :
#                     super(Book, self).save(*args, **kwargs)
#                     return True
#                 else:
#                     return False
#             else:
#                 super(Book, self).save(*args, **kwargs)
#                 return True
#             # super(Book, self).save(*args, **kwargs)
#             # return True


    def save(self, *args, **kwargs):
        # if exists(self,'index') and self.exists('index'):
            # return reverse('model_files:book.overwrite')
        # raise ValidationError(self.index.open('rb').read())
        d=0
        # raise ValidationError('H')
        # delete_file_if_needed(self, 'index')
        try:
            if not self.pk:  # file is new
                md5 = hashlib.md5()
                for chunk in self.index.chunks():
                    md5.update(chunk)
                self.md5s = md5.hexdigest()
        except ValueError:
            d=1
            # raise ValidationError('H')
            # encrypted_file =  subprocess.call(['gpg','--yes','--batch','--passphrase="a"','-c',self.index])
#        delete_file_if_needed(self, 'pages')
        # else:
        # try:
        #     super(Book, self).save(*args, **kwargs)
        # except:
        # raise ValidationError(self.index.open('rb').read())

        if Book.objects.filter(name=self.name,ownr=self.ownr):
            sd=Book.objects.get(name=self.name,ownr=self.ownr)

            if self.md5se:
                sd.delete()
                super(Book, self).save(*args, **kwargs)
                return True
            else:
                if sd.md5s!=self.md5s:
                    return False
                else:
                    return True
                        # raise ValidationError(self.md5s)
                    # return redirect('model_files:book.edit', kwargs={'pk': sd.pk})
        else:
            if self.md5se:
                if self.md5s == self.md5se :
                    super(Book, self).save(*args, **kwargs)
                    return True
                else:
                    return False
            else:
                # raise ValidationError('Hi')
                if d==0:
                    self.md5so = self.md5s
                    # super(Book, self).itii(key,scm)
                    if self.l=="1":
                        if self.scm=="des":
                        # PT", CBC, "12345678" , pad=None , padmode =PAD_PKCS5)
                            enc = des("DESCRYPT", CBC, self.key , pad=None , padmode =PAD_PKCS5)
                            plt = enc.encrypt(self.index.open('rb').read())
                            self.index.open('wb').write(plt)
                            # self.index.close()
                            # raise ValidationError(self.index.open('rb').read())

                            super(Book, self).save(*args, **kwargs)
                        elif self.scm=="aes":
                            enc =Encryptor(self.key)
                            # enc = des("DESCRYPT", CBC, self.key , pad=None , padmode =PAD_PKCS5)
                            plt = enc.encrypt(self.index.open('rb').read())
                            self.index.open('wb').write(plt)
                            super(Book, self).save(*args, **kwargs)
                            # raise ValidationError('Hi')
                        elif self.scm=="bf":
                            enc = blowfish.Cipher(self.key.encode())
                            iv1=b"\xf9\x11\xeb\x8a\x871\x98\x89"
                            plt = b"".join(enc.encrypt_cfb(self.index.open('rb').read(),iv1))
                            self.index.open('wb').write(plt)
                            super(Book, self).save(*args, **kwargs)
                    else:
                        super(Book, self).save(*args, **kwargs)
                else:
                    # raise ValidationError('Hi')
                    super(Book, self).save(*args, **kwargs)

                return True




    def it(self,k,s):
        self.key=k
        self.scm=s        
    # def it2(self,l):
    def it2(self,l):
        self.l=l
    #     self.l=l
        # raise ValidationError(self.l)
    def delete(self, *args, **kwargs):
        super(Book, self).delete(*args, **kwargs)
        delete_file(self, 'index')
#        delete_file(self, 'pages')
    def __str__(self):
        return self.name
    def crtd(self):
        return self.created_at
#
#
#class SoundDeviceInstructionManual(models.Model):
#    bytes = models.TextField()
#    filename = models.CharField(max_length=255)
#    mimetype = models.CharField(max_length=50)
#
#
#class SoundDevice(models.Model):
#    name = models.CharField(max_length=100)
#    instruction_manual = models.FileField(
#        upload_to='model_filefields_example.SoundDeviceInstructionManual'
#                  '/bytes/filename/mimetype',
#        blank=True,
#        null=True
#    )

