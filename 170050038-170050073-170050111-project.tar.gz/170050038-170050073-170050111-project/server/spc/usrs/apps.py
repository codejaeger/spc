from django.apps import AppConfig


class UsrsConfig(AppConfig):
    name = 'usrs'
